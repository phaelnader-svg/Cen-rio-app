#!/usr/bin/env bash
# Preparação da VM de PRODUÇÃO cenario-prod (Debian 12, Compute Engine), como root. Executado pelo
# "provisionar.sh preparar-vm" (via IAP) e seguro para rodar de novo a qualquer momento. Derivado do
# startup.sh homologado; muda só o nome dos serviços (cenario-prod) e o caminho (infra/prod). Idempotente:
#   - Docker Engine + Compose: instala SÓ se ausentes (na VM atual já existem: nada é alterado);
#   - swap: cria /swapfile de 2 GB SÓ se não houver NENHUMA swap ativa nem declarada no /etc/fstab
#     (a VM atual já tem 2 GB: nada é alterado);
#   - atualizações automáticas de segurança (unattended-upgrades): instala/ativa se ausentes;
#   - systemd-resolved sem LLMNR/mDNS (nenhuma escuta em 5355/5353 fora do loopback);
#   - serviço systemd da pilha COM PORTÃO DE PUBLICAÇÃO: só roda se existir
#     /etc/cenario/publicacao-autorizada. Este script NUNCA cria esse arquivo e NUNCA
#     inicia a pilha sem ele (nem PostgreSQL, nem migrations, nem portas 80/443). Rodar este
#     script COM o portão aberto (re)inicia a pilha: para só atualizar as unidades, rode com ele fechado;
#   - envio diário dos backups ao bucket (timer 07:30 UTC), SEM o portão: só lê os backups e cria
#     objetos no bucket com a conta da VM (nenhum segredo, nada iniciado).
# Nenhum segredo é lido nem gravado aqui.
# CENARIO_RAIZ (só nos testes) prefixa os caminhos do sistema, para executar sem tocar na máquina.
set -euo pipefail
R="${CENARIO_RAIZ:-}"
PORTAO=/etc/cenario/publicacao-autorizada
exec > >(tee >(logger -t cenario-startup)) 2>&1

if ! command -v docker >/dev/null 2>&1 || ! docker compose version >/dev/null 2>&1; then
  echo "Docker/Compose ausentes: instalando do repositório oficial da Docker"
  apt-get update
  apt-get install -y ca-certificates curl gnupg
  install -m 0755 -d "$R/etc/apt/keyrings"
  curl -fsSL https://download.docker.com/linux/debian/gpg -o "$R/etc/apt/keyrings/docker.asc"
  chmod a+r "$R/etc/apt/keyrings/docker.asc"
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/debian $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
    > "$R/etc/apt/sources.list.d/docker.list"
  apt-get update
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
  systemctl enable --now docker
else
  echo "Docker $(docker --version | cut -d' ' -f3 | tr -d ,) e Compose $(docker compose version --short) já instalados: mantidos"
fi

# Swap: qualquer swap ativa (arquivo ou partição, com qualquer nome) já basta.
if [[ -n "$(swapon --show --noheadings 2>/dev/null)" ]]; then
  echo "swap já ativa: $(swapon --show=NAME,SIZE --noheadings | xargs): mantida"
elif grep -qE '^[^#[:space:]]+[[:space:]]+[^[:space:]]+[[:space:]]+swap[[:space:]]' "$R/etc/fstab" 2>/dev/null; then
  echo "swap declarada no /etc/fstab mas inativa: ativando (swapon -a)"
  swapon -a
else
  echo "sem swap: criando /swapfile de 2 GB"
  fallocate -l 2G "$R/swapfile" && chmod 600 "$R/swapfile" && mkswap "$R/swapfile"
  echo '/swapfile none swap sw 0 0' >> "$R/etc/fstab"
  swapon "$R/swapfile"
fi
if [[ ! -f "$R/etc/sysctl.d/90-cenario-swap.conf" ]]; then
  echo 'vm.swappiness=10' > "$R/etc/sysctl.d/90-cenario-swap.conf"
  sysctl -q -w vm.swappiness=10 || true
fi

# Atualizações automáticas de segurança (Debian security), sem reinício automático.
if ! dpkg -s unattended-upgrades >/dev/null 2>&1; then
  apt-get update && apt-get install -y unattended-upgrades
fi
if [[ ! -f "$R/etc/apt/apt.conf.d/20auto-upgrades" ]] || ! grep -q 'Unattended-Upgrade "1"' "$R/etc/apt/apt.conf.d/20auto-upgrades"; then
  printf 'APT::Periodic::Update-Package-Lists "1";\nAPT::Periodic::Unattended-Upgrade "1";\n' > "$R/etc/apt/apt.conf.d/20auto-upgrades"
fi

# LLMNR/mDNS desativados (persistente). A imagem debian-12 atual traz o systemd-resolved ativo com o
# padrão LLMNR=yes, que escuta em 0.0.0.0:5355 (TCP e UDP). Na VPC isso não tem uso (resolução pelo
# servidor de metadados; sem multicast) e LLMNR é vetor conhecido de envenenamento de nomes. Em vez de
# liberar a porta no portão de preparo (que continua exigindo só 22), o serviço deixa de escutar.
# Idempotente: o systemd-resolved só é reiniciado se o arquivo mudou ou se 5355/5353 ainda escutam.
install -d -m 755 "$R/etc/systemd/resolved.conf.d"
RESOLVED_CONF="$R/etc/systemd/resolved.conf.d/90-cenario-sem-llmnr.conf"
RESOLVED_ESPERADO=$'# Cenário Gestão (infra/prod/gcp/startup.sh): sem LLMNR (5355) nem mDNS (5353)\n[Resolve]\nLLMNR=no\nMulticastDNS=no'
resolved_mudou=0
if [[ "$(cat "$RESOLVED_CONF" 2>/dev/null)" != "$RESOLVED_ESPERADO" ]]; then
  printf '%s\n' "$RESOLVED_ESPERADO" > "$RESOLVED_CONF"; chmod 644 "$RESOLVED_CONF"; resolved_mudou=1
fi
if systemctl is-active --quiet systemd-resolved 2>/dev/null; then
  escutando=""
  command -v ss >/dev/null 2>&1 && escutando="$(ss -tulnH 2>/dev/null | awk '{print $5}' | grep -E ':(5355|5353)$' || true)"
  if (( resolved_mudou )) || [[ -n "$escutando" ]]; then
    echo "systemd-resolved: LLMNR e mDNS desativados ($RESOLVED_CONF); reiniciando o serviço"
    systemctl restart systemd-resolved
  else
    echo "systemd-resolved: LLMNR e mDNS já desativados: mantido"
  fi
else
  echo "systemd-resolved inativo: configuração gravada para quando for ativado ($RESOLVED_CONF)"
fi

install -d -m 755 "$R/opt/cenario" "$R/etc/cenario"
cat > "$R/etc/systemd/system/cenario-prod.service" <<EOF
[Unit]
Description=Cenário Gestão — PRODUÇÃO (Docker Compose)
After=docker.service network-online.target
Wants=network-online.target
Requires=docker.service
ConditionPathExists=/opt/cenario/infra/prod/gcp/vm.sh
# Portão: sem a autorização explícita do operador, o serviço não faz nada (nem no boot).
ConditionPathExists=$PORTAO

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/bash -c '/opt/cenario/infra/prod/gcp/vm.sh gerar-env && /opt/cenario/infra/prod/gcp/vm.sh iniciar'
ExecStop=/opt/cenario/infra/prod/gcp/vm.sh parar
TimeoutStartSec=900

[Install]
WantedBy=multi-user.target
EOF
# Envio dos backups ao bucket: SEM o portão de publicação. O portão protege a pilha (segredos,
# PostgreSQL, portas) e fica fechado na operação normal; o envio só LÊ as pastas de backup e CRIA
# objetos no bucket com a conta da VM (nenhum segredo, nada iniciado). Com o portão como condição,
# o envio diário era pulado sempre que o portão estava fechado (produção: sem cópia externa de
# 23/10 a 13/11/2026). Sem volume de backups (antes do 1º deploy), o envio não faz nada.
cat > "$R/etc/systemd/system/cenario-backup-upload.service" <<EOF
[Unit]
Description=Cenário Gestão — envio dos backups ao Cloud Storage
After=cenario-prod.service
ConditionPathExists=/opt/cenario/infra/prod/gcp/vm.sh

[Service]
Type=oneshot
ExecStart=/opt/cenario/infra/prod/gcp/vm.sh enviar-backups
EOF
cat > "$R/etc/systemd/system/cenario-backup-upload.timer" <<'EOF'
[Unit]
Description=Envio diário dos backups da produção

[Timer]
OnCalendar=*-*-* 07:30:00 UTC
Persistent=true

[Install]
WantedBy=timers.target
EOF
systemctl daemon-reload
systemctl enable cenario-prod.service cenario-backup-upload.timer
systemctl start cenario-backup-upload.timer # envio diário (independe do portão)

if [[ -f "$R$PORTAO" && -x "$R/opt/cenario/infra/prod/gcp/vm.sh" ]]; then
  echo "publicação autorizada ($PORTAO): (re)iniciando a pilha"
  systemctl restart cenario-prod.service
else
  echo "publicação NÃO autorizada ($PORTAO ausente): nada foi iniciado"
fi
